package com.example.mediahub.ui.player

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.mediahub.MediaHubApp
import com.example.mediahub.core.database.WatchProgressEntity
import com.example.mediahub.core.power.ScreenSleepManager
import com.example.mediahub.domain.model.StreamSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PlayerActivity : AppCompatActivity() {

    private var exoPlayer: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var blackOverlayView: FrameLayout
    private lateinit var sleepManager: ScreenSleepManager
    private lateinit var timerBadgeView: TextView
    private var progressSaveJob: Job? = null

    private var currentTitle: String = "Reprodução"
    private var currentTmdbId: Int = 1001
    private var currentMediaType: String = "movie"
    private var currentSeason: Int? = null
    private var currentEpisode: Int? = null
    private lateinit var activeStreamSource: StreamSource

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootContainer = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
        }

        playerView = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Top Bar Controls for Battery Saving & Sleep Mode
        val topOverlayBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x88000000.toInt())
            setPadding(24)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        }

        val btnOledBlackout = Button(this).apply {
            text = "Modo Tela Preta (OLED)"
            setOnClickListener {
                sleepManager.enableOledBlackout(exoPlayer)
                Toast.makeText(
                    this@PlayerActivity,
                    "Economia extrema ativa. Toque na tela para restaurar o vídeo.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val btnSleepTimer = Button(this).apply {
            text = "Timer Dormir"
            setOnClickListener { showSleepTimerDialog() }
        }

        timerBadgeView = TextView(this).apply {
            text = ""
            setTextColor(0xFF81C784.toInt())
            setPadding(24, 0, 0, 0)
        }

        topOverlayBar.addView(btnOledBlackout)
        topOverlayBar.addView(btnSleepTimer)
        topOverlayBar.addView(timerBadgeView)

        // OLED Blackout Overlay (#000000)
        blackOverlayView = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            val hintText = TextView(this@PlayerActivity).apply {
                text = "Modo Economia OLED Ativo (Somente Áudio)
Toque em qualquer lugar para religar a tela"
                setTextColor(0xFF333333.toInt())
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            }
            addView(hintText)
            setOnClickListener {
                sleepManager.disableOledBlackout(exoPlayer)
            }
        }

        rootContainer.addView(playerView)
        rootContainer.addView(topOverlayBar)
        rootContainer.addView(blackOverlayView)
        setContentView(rootContainer)

        sleepManager = ScreenSleepManager(
            window = window,
            playerView = playerView,
            blackOverlayView = blackOverlayView,
            onSleepTriggered = {
                exoPlayer?.pause()
                savePlaybackProgress()
                timerBadgeView.text = "Modo Dormir acionado (WakeLock liberado)"
            }
        )

        currentTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Stream"
        currentTmdbId = intent.getIntExtra(EXTRA_TMDB_ID, 1001)
        currentMediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE) ?: "movie"
        currentSeason = intent.getIntExtra(EXTRA_SEASON_NUMBER, -1).takeIf { it > 0 }
        currentEpisode = intent.getIntExtra(EXTRA_EPISODE_NUMBER, -1).takeIf { it > 0 }

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL) ?: return
        val referer = intent.getStringExtra(EXTRA_REFERER) ?: ""
        val userAgent = intent.getStringExtra(EXTRA_USER_AGENT)?.takeIf { it.isNotBlank() } ?: DEFAULT_USER_AGENT
        val origin = intent.getStringExtra(EXTRA_ORIGIN) ?: ""
        val startPositionMs = intent.getLongExtra(EXTRA_START_POSITION_MS, 0L)

        activeStreamSource = StreamSource(
            url = streamUrl,
            quality = "Auto",
            headers = buildMap {
                put("User-Agent", userAgent)
                if (referer.isNotBlank()) put("Referer", referer)
                if (origin.isNotBlank()) put("Origin", origin)
            }
        )

        initializePlayer(activeStreamSource, startPositionMs)
    }

    private fun showSleepTimerDialog() {
        val options = arrayOf("15 minutos", "30 minutos", "45 minutos", "60 minutos", "Desativar Timer")
        val minutesValues = intArrayOf(15, 30, 45, 60, 0)

        AlertDialog.Builder(this)
            .setTitle("Programar Modo Dormir")
            .setItems(options) { _, which ->
                val minutes = minutesValues[which]
                if (minutes > 0) {
                    sleepManager.startSleepTimer(minutes) { remaining ->
                        timerBadgeView.text = "Dormir em ${remaining} min"
                    }
                } else {
                    sleepManager.cancelSleepTimer()
                    timerBadgeView.text = ""
                }
            }
            .show()
    }

    private fun initializePlayer(source: StreamSource, startPositionMs: Long) {
        val dataSourceFactory = OkHttpDataSource.Factory(MediaHubApp.instance.okHttpClient)
            .setUserAgent(source.headers["User-Agent"] ?: DEFAULT_USER_AGENT)
            .setDefaultRequestProperties(source.headers)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                30_000,
                120_000,
                2_500,
                5_000
            )
            .build()

        exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .setLoadControl(loadControl)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
            .also { player ->
                playerView.player = player
                player.addListener(sleepManager)

                val mimeType = when {
                    source.url.contains(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
                    source.url.contains(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
                    else -> null
                }

                val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(source.url))
                if (mimeType != null) {
                    mediaItemBuilder.setMimeType(mimeType)
                }

                player.setMediaItem(mediaItemBuilder.build())
                if (startPositionMs > 0L) {
                    player.seekTo(startPositionMs)
                }
                player.prepare()
                player.playWhenReady = true
            }

        startPeriodicProgressSaver()
    }

    private fun startPeriodicProgressSaver() {
        progressSaveJob?.cancel()
        progressSaveJob = lifecycleScope.launch {
            while (isActive) {
                delay(15_000L)
                savePlaybackProgress()
            }
        }
    }

    private fun savePlaybackProgress() {
        val player = exoPlayer ?: return
        val currentPosition = player.currentPosition
        if (currentPosition <= 0L) return
        val duration = player.duration.coerceAtLeast(1L)

        val entity = WatchProgressEntity(
            tmdbId = currentTmdbId,
            mediaType = currentMediaType,
            title = currentTitle,
            posterPath = null,
            seasonNumber = currentSeason,
            episodeNumber = currentEpisode,
            lastStreamUrl = activeStreamSource.url,
            refererHeader = activeStreamSource.headers["Referer"].orEmpty(),
            userAgentHeader = activeStreamSource.headers["User-Agent"].orEmpty(),
            originHeader = activeStreamSource.headers["Origin"].orEmpty(),
            positionMs = currentPosition,
            durationMs = duration,
            updatedAtEpochMs = System.currentTimeMillis()
        )

        lifecycleScope.launch(Dispatchers.IO) {
            MediaHubApp.instance.catalogRepository.saveWatchProgress(entity)
        }
    }

    override fun onStop() {
        super.onStop()
        savePlaybackProgress()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        progressSaveJob?.cancel()
        sleepManager.release()
        exoPlayer?.removeListener(sleepManager)
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_TMDB_ID = "extra_tmdb_id"
        const val EXTRA_MEDIA_TYPE = "extra_media_type"
        const val EXTRA_SEASON_NUMBER = "extra_season_number"
        const val EXTRA_EPISODE_NUMBER = "extra_episode_number"
        const val EXTRA_STREAM_URL = "extra_stream_url"
        const val EXTRA_REFERER = "extra_referer"
        const val EXTRA_USER_AGENT = "extra_user_agent"
        const val EXTRA_ORIGIN = "extra_origin"
        const val EXTRA_START_POSITION_MS = "extra_start_position_ms"
        const val DEFAULT_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
    }
}
