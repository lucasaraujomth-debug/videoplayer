package com.example.mediahub.domain.model

data class CatalogItem(
    val tmdbId: Int,
    val title: String,
    val overview: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val rating: Double,
    val mediaType: String, // "movie" or "tv"
    val releaseYear: Int?
)

data class CastMember(
    val id: Int,
    val name: String,
    val character: String,
    val profileUrl: String?
)

data class EpisodeItem(
    val id: Int,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val overview: String,
    val stillUrl: String?
)

data class SeasonSummary(
    val seasonNumber: Int,
    val name: String,
    val episodeCount: Int
)

data class MediaDetails(
    val item: CatalogItem,
    val genres: List<String>,
    val cast: List<CastMember>,
    val seasons: List<SeasonSummary>,
    val isFavorite: Boolean
)
