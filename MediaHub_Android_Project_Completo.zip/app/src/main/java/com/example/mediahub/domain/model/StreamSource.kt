package com.example.mediahub.domain.model

data class StreamSource(
    val url: String,
    val quality: String,
    val headers: Map<String, String>
)
