package com.example.mediahub.data.parser

import com.example.mediahub.domain.model.StreamSource
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

data class IptvChannel(
    val id: String,
    val name: String,
    val group: String,
    val logoUrl: String?,
    val streamSource: StreamSource
)

class M3uParser {

    private val tvgIdRegex = Regex("""tvg-id="([^"]*)"""")
    private val tvgLogoRegex = Regex("""tvg-logo="([^"]*)"""")
    private val groupTitleRegex = Regex("""group-title="([^"]*)"""")

    fun parse(inputStream: InputStream, defaultUserAgent: String = "Lavf/60.3.100"): List<IptvChannel> {
        val channels = mutableListOf<IptvChannel>()
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

        var currentName = ""
        var currentId = ""
        var currentLogo: String? = null
        var currentGroup = ""
        val currentHeaders = mutableMapOf<String, String>()

        reader.useLines { lines ->
            for (rawLine in lines) {
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#EXTM3U")) continue

                when {
                    line.startsWith("#EXTINF:", ignoreCase = true) -> {
                        currentId = tvgIdRegex.find(line)?.groupValues?.getOrNull(1).orEmpty()
                        currentLogo = tvgLogoRegex.find(line)?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }
                        currentGroup = groupTitleRegex.find(line)?.groupValues?.getOrNull(1).orEmpty()
                        currentName = line.substringAfterLast(",", "Canal Sem Nome").trim()
                    }

                    line.startsWith("#EXTVLCOPT:http-user-agent=", ignoreCase = true) -> {
                        currentHeaders["User-Agent"] = line.substringAfter("=").trim()
                    }

                    line.startsWith("#EXTVLCOPT:http-referrer=", ignoreCase = true) -> {
                        currentHeaders["Referer"] = line.substringAfter("=").trim()
                    }

                    !line.startsWith("#") -> {
                        val cleanUrl = line.substringBefore("|").trim()
                        val inlineParams = line.substringAfter("|", "")
                        if (inlineParams.isNotEmpty()) {
                            inlineParams.split("&").forEach { kv ->
                                val parts = kv.split("=", limit = 2)
                                if (parts.size == 2) {
                                    currentHeaders[parts[0].trim()] = parts[1].trim()
                                }
                            }
                        }

                        val resolvedGroup = currentGroup.ifBlank { autoCategorize(currentName, cleanUrl) }
                        val headers = mapOf(
                            "User-Agent" to (currentHeaders["User-Agent"] ?: defaultUserAgent),
                            "Referer" to (currentHeaders["Referer"] ?: ""),
                            "Origin" to (currentHeaders["Origin"] ?: "")
                        )

                        channels.add(
                            IptvChannel(
                                id = currentId.ifBlank { cleanUrl.hashCode().toString() },
                                name = currentName.ifBlank { "Canal ${channels.size + 1}" },
                                group = resolvedGroup,
                                logoUrl = currentLogo,
                                streamSource = StreamSource(
                                    url = cleanUrl,
                                    quality = if (currentName.contains("4K", true)) "4K" else "HD",
                                    headers = headers
                                )
                            )
                        )

                        currentName = ""
                        currentId = ""
                        currentLogo = null
                        currentGroup = ""
                        currentHeaders.clear()
                    }
                }
            }
        }
        return channels
    }

    private fun autoCategorize(name: String, url: String): String {
        val text = "$name $url".lowercase()
        return when {
            text.contains("esporte") || text.contains("sport") || text.contains("premiere") || text.contains("espn") -> "Esportes"
            text.contains("filme") || text.contains("movie") || text.contains("telecine") || text.contains("hbo") -> "Filmes"
            text.contains("serie") || text.contains("s0") || text.contains("/series/") -> "Séries"
            text.contains("infantil") || text.contains("kids") || text.contains("cartoon") || text.contains("disney") -> "Infantil"
            text.contains("noticia") || text.contains("news") || text.contains("cnn") || text.contains("globonews") -> "Notícias"
            else -> "Canais Gerais"
        }
    }
}
