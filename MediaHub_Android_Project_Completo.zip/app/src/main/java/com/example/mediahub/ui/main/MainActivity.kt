package com.example.mediahub.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.lifecycle.lifecycleScope
import com.example.mediahub.MediaHubApp
import com.example.mediahub.domain.model.CatalogItem
import com.example.mediahub.ui.details.DetailsActivity
import com.example.mediahub.ui.player.PlayerActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var continueWatchingContainer: LinearLayout
    private lateinit var trendingContainer: LinearLayout
    private lateinit var iptvChannelsContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootScroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0E1015.toInt())
        }

        val mainColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36)
        }

        val headerTitle = TextView(this).apply {
            text = "MediaHub • Catálogo, IPTV & Web Sniffer"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
        }
        mainColumn.addView(headerTitle)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 24, 0, 24)
        }

        val btnWebSniffer = Button(this).apply {
            text = "Web Sniffer (Extrair .m3u8)"
            setOnClickListener { showWebSnifferDialog() }
        }
        val btnImportM3u = Button(this).apply {
            text = "Carregar M3U / Xtream"
            setOnClickListener { showM3uImportDialog() }
        }
        actionRow.addView(btnWebSniffer)
        actionRow.addView(btnImportM3u)
        mainColumn.addView(actionRow)

        mainColumn.addView(sectionHeader("Continuar Assistindo (Room DB)"))
        continueWatchingContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        mainColumn.addView(continueWatchingContainer)

        mainColumn.addView(sectionHeader("Em Alta no Catálogo (TMDB / Stremio Style)"))
        trendingContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        mainColumn.addView(trendingContainer)

        mainColumn.addView(sectionHeader("Canais IPTV / Listas M3U Categorizadas"))
        iptvChannelsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        mainColumn.addView(iptvChannelsContainer)

        rootScroll.addView(mainColumn)
        setContentView(rootScroll)

        observeRoomContinueWatching()
        loadCatalogData()
        loadSampleM3uChannels()
    }

    private fun sectionHeader(title: String): TextView {
        return TextView(this).apply {
            text = title
            textSize = 18f
            setTextColor(0xFF64B5F6.toInt())
            setPadding(0, 32, 0, 12)
        }
    }

    private fun observeRoomContinueWatching() {
        val repo = MediaHubApp.instance.catalogRepository
        lifecycleScope.launch {
            repo.observeContinueWatching().collectLatest { list ->
                continueWatchingContainer.removeAllViews()
                if (list.isEmpty()) {
                    val emptyView = TextView(this@MainActivity).apply {
                        text = "Nenhum vídeo em andamento. Inicie um título para salvar o ponto de parada automaticamente."
                        setTextColor(0xFF9E9E9E.toInt())
                    }
                    continueWatchingContainer.addView(emptyView)
                } else {
                    list.forEach { progress ->
                        val minutes = (progress.positionMs / 1000) / 60
                        val seconds = (progress.positionMs / 1000) % 60
                        val btn = Button(this@MainActivity).apply {
                            text = "▶ ${progress.title} (Retomar em %02d:%02d)".format(minutes, seconds)
                            setOnClickListener {
                                launchPlayer(
                                    title = progress.title,
                                    tmdbId = progress.tmdbId,
                                    mediaType = progress.mediaType,
                                    url = progress.lastStreamUrl,
                                    referer = progress.refererHeader,
                                    userAgent = progress.userAgentHeader,
                                    origin = progress.originHeader,
                                    startPosMs = progress.positionMs
                                )
                            }
                        }
                        continueWatchingContainer.addView(btn)
                    }
                }
            }
        }
    }

    private fun loadCatalogData() {
        val repo = MediaHubApp.instance.catalogRepository
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) { repo.getTrendingCatalog() }
            trendingContainer.removeAllViews()
            items.forEach { item ->
                trendingContainer.addView(createCatalogCard(item))
            }
        }
    }

    private fun createCatalogCard(item: CatalogItem): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1A1D24.toInt())
            setPadding(24)
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 0, 0, 20)
            layoutParams = params

            val titleView = TextView(this@MainActivity).apply {
                text = "${item.title} (${item.releaseYear ?: "N/A"}) • ★ ${item.rating}"
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
            }
            val descView = TextView(this@MainActivity).apply {
                text = item.overview
                textSize = 13f
                setTextColor(0xFFB0BEC5.toInt())
                setPadding(0, 8, 0, 12)
            }
            val openDetailsBtn = Button(this@MainActivity).apply {
                text = if (item.mediaType == "tv") "Ver Temporadas & Episódios" else "Abrir Detalhes & Fontes"
                setOnClickListener {
                    val intent = Intent(this@MainActivity, DetailsActivity::class.java).apply {
                        putExtra(DetailsActivity.EXTRA_TMDB_ID, item.tmdbId)
                        putExtra(DetailsActivity.EXTRA_MEDIA_TYPE, item.mediaType)
                    }
                    startActivity(intent)
                }
            }

            addView(titleView)
            addView(descView)
            addView(openDetailsBtn)
        }
    }

    private fun loadSampleM3uChannels() {
        val sampleM3u = """
            #EXTM3U
            #EXTINF:-1 tvg-id="bbb" group-title="Filmes",Big Buck Bunny HLS (Teste Modo Dormir)
            https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8
            #EXTINF:-1 tvg-id="apple" group-title="Séries",Apple BipBop Advanced HLS
            https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8
        """.trimIndent()

        renderM3uString(sampleM3u)
    }

    private fun renderM3uString(m3uContent: String) {
        lifecycleScope.launch {
            val channels = withContext(Dispatchers.IO) {
                MediaHubApp.instance.m3uParser.parse(ByteArrayInputStream(m3uContent.toByteArray()))
            }
            iptvChannelsContainer.removeAllViews()
            channels.forEach { ch ->
                val btn = Button(this@MainActivity).apply {
                    text = "[${ch.group}] ${ch.name} (${ch.streamSource.quality})"
                    setOnClickListener {
                        launchPlayer(
                            title = ch.name,
                            tmdbId = ch.id.hashCode(),
                            mediaType = "live",
                            url = ch.streamSource.url,
                            referer = ch.streamSource.headers["Referer"].orEmpty(),
                            userAgent = ch.streamSource.headers["User-Agent"].orEmpty(),
                            origin = ch.streamSource.headers["Origin"].orEmpty(),
                            startPosMs = 0L
                        )
                    }
                }
                iptvChannelsContainer.addView(btn)
            }
        }
    }

    private fun showWebSnifferDialog() {
        val input = EditText(this).apply {
            hint = "https://site-com-video.com ou nome do filme"
            setText("https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8")
        }

        AlertDialog.Builder(this)
            .setTitle("Web Sniffer (AdBlock + Extrator .m3u8/.mp4)")
            .setMessage("Insira a URL da página web ou termo de busca para interceptar o stream e os cabeçalhos Referer/Origin:")
            .setView(input)
            .setPositiveButton("Extrair & Reproduzir") { _, _ ->
                val query = input.text.toString().trim()
                if (query.isNotEmpty()) {
                    runSnifferExtraction(query)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun runSnifferExtraction(query: String) {
        Toast.makeText(this, "Iniciando Sniffer com AdBlock...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val results = MediaHubApp.instance.webStreamExtractor.searchAndExtract(query, null)
            if (results.isNotEmpty()) {
                val first = results.first()
                launchPlayer(
                    title = "Stream Extraído (${first.quality})",
                    tmdbId = first.url.hashCode(),
                    mediaType = "movie",
                    url = first.url,
                    referer = first.headers["Referer"].orEmpty(),
                    userAgent = first.headers["User-Agent"].orEmpty(),
                    origin = first.headers["Origin"].orEmpty(),
                    startPosMs = 0L
                )
            } else if (query.contains(".m3u8") || query.contains(".mp4")) {
                launchPlayer(
                    title = "Stream Direto",
                    tmdbId = query.hashCode(),
                    mediaType = "movie",
                    url = query,
                    referer = "",
                    userAgent = PlayerActivity.DEFAULT_USER_AGENT,
                    origin = "",
                    startPosMs = 0L
                )
            } else {
                Toast.makeText(this@MainActivity, "Nenhum stream .m3u8/.mp4 detectado na página.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showM3uImportDialog() {
        val input = EditText(this).apply {
            hint = "Cole aqui o conteúdo #EXTM3U..."
            minLines = 4
        }

        AlertDialog.Builder(this)
            .setTitle("Importar Lista M3U / M3U8")
            .setView(input)
            .setPositiveButton("Processar Lista") { _, _ ->
                val content = input.text.toString()
                if (content.isNotBlank()) {
                    renderM3uString(content)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun launchPlayer(
        title: String,
        tmdbId: Int,
        mediaType: String,
        url: String,
        referer: String,
        userAgent: String,
        origin: String,
        startPosMs: Long
    ) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_TITLE, title)
            putExtra(PlayerActivity.EXTRA_TMDB_ID, tmdbId)
            putExtra(PlayerActivity.EXTRA_MEDIA_TYPE, mediaType)
            putExtra(PlayerActivity.EXTRA_STREAM_URL, url)
            putExtra(PlayerActivity.EXTRA_REFERER, referer)
            putExtra(PlayerActivity.EXTRA_USER_AGENT, userAgent)
            putExtra(PlayerActivity.EXTRA_ORIGIN, origin)
            putExtra(PlayerActivity.EXTRA_START_POSITION_MS, startPosMs)
        }
        startActivity(intent)
    }
}
