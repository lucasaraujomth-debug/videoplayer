package com.example.mediahub.domain.repository

import com.example.mediahub.core.database.FavoriteMediaEntity
import com.example.mediahub.core.database.WatchProgressEntity
import com.example.mediahub.domain.model.CatalogItem
import com.example.mediahub.domain.model.EpisodeItem
import com.example.mediahub.domain.model.MediaDetails
import kotlinx.coroutines.flow.Flow

interface CatalogRepository {
    suspend fun getTrendingCatalog(): List<CatalogItem>
    suspend fun getMoviesByGenre(genreId: Int): List<CatalogItem>
    suspend fun getSeriesByGenre(genreId: Int): List<CatalogItem>
    suspend fun getMediaDetails(mediaType: String, tmdbId: Int): MediaDetails
    suspend fun getSeasonEpisodes(seriesId: Int, seasonNumber: Int): List<EpisodeItem>
    fun observeContinueWatching(): Flow<List<WatchProgressEntity>>
    fun observeFavorites(): Flow<List<FavoriteMediaEntity>>
    suspend fun saveWatchProgress(entity: WatchProgressEntity)
    suspend fun toggleFavorite(item: CatalogItem)
}
