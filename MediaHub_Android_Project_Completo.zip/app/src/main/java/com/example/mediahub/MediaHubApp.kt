package com.example.mediahub

import android.app.Application
import androidx.room.Room
import com.example.mediahub.core.database.AppDatabase
import com.example.mediahub.data.parser.M3uParser
import com.example.mediahub.data.remote.TmdbApiService
import com.example.mediahub.data.repository.CatalogRepositoryImpl
import com.example.mediahub.data.sniffer.WebViewStreamExtractor
import com.example.mediahub.domain.repository.CatalogRepository
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class MediaHubApp : Application() {

    val database: AppDatabase by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "mediahub.db"
        ).fallbackToDestructiveMigration().build()
    }

    val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    val tmdbApi: TmdbApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.themoviedb.org/3/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TmdbApiService::class.java)
    }

    val catalogRepository: CatalogRepository by lazy {
        CatalogRepositoryImpl(
            tmdbApi = tmdbApi,
            dao = database.watchHistoryDao(),
            apiKey = BuildConfig.TMDB_API_KEY
        )
    }

    val m3uParser: M3uParser by lazy { M3uParser() }

    val webStreamExtractor: WebViewStreamExtractor by lazy {
        WebViewStreamExtractor(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: MediaHubApp
            private set
    }
}
