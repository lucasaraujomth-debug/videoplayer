package com.example.mediahub.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class TmdbPagedResponse<T>(
    @SerializedName("page") val page: Int,
    @SerializedName("results") val results: List<T>,
    @SerializedName("total_pages") val totalPages: Int
)

data class TmdbMediaSummaryDto(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("overview") val overview: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val voteAverage: Double?,
    @SerializedName("media_type") val mediaType: String?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?
)

data class TmdbDetailsDto(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("overview") val overview: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val voteAverage: Double?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?,
    @SerializedName("genres") val genres: List<TmdbGenreDto>?,
    @SerializedName("credits") val credits: TmdbCreditsDto?,
    @SerializedName("seasons") val seasons: List<TmdbSeasonSummaryDto>?
)

data class TmdbGenreDto(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String
)

data class TmdbCreditsDto(
    @SerializedName("cast") val cast: List<TmdbCastMemberDto>?
)

data class TmdbCastMemberDto(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("character") val character: String?,
    @SerializedName("profile_path") val profilePath: String?
)

data class TmdbSeasonSummaryDto(
    @SerializedName("season_number") val seasonNumber: Int,
    @SerializedName("name") val name: String,
    @SerializedName("episode_count") val episodeCount: Int
)

data class TmdbSeasonDetailsDto(
    @SerializedName("id") val id: Int,
    @SerializedName("season_number") val seasonNumber: Int,
    @SerializedName("episodes") val episodes: List<TmdbEpisodeDto>?
)

data class TmdbEpisodeDto(
    @SerializedName("id") val id: Int,
    @SerializedName("episode_number") val episodeNumber: Int,
    @SerializedName("name") val name: String,
    @SerializedName("overview") val overview: String?,
    @SerializedName("still_path") val stillPath: String?
)

interface TmdbApiService {

    @GET("trending/{media_type}/{time_window}")
    suspend fun getTrending(
        @Path("media_type") mediaType: String = "all",
        @Path("time_window") timeWindow: String = "week",
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "pt-BR",
        @Query("page") page: Int = 1
    ): TmdbPagedResponse<TmdbMediaSummaryDto>

    @GET("discover/{media_type}")
    suspend fun discoverByGenre(
        @Path("media_type") mediaType: String,
        @Query("with_genres") genreId: Int,
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "pt-BR",
        @Query("page") page: Int = 1
    ): TmdbPagedResponse<TmdbMediaSummaryDto>

    @GET("{media_type}/{id}")
    suspend fun getMediaDetails(
        @Path("media_type") mediaType: String,
        @Path("id") tmdbId: Int,
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "pt-BR",
        @Query("append_to_response") appendToResponse: String = "credits"
    ): TmdbDetailsDto

    @GET("tv/{series_id}/season/{season_number}")
    suspend fun getSeasonEpisodes(
        @Path("series_id") seriesId: Int,
        @Path("season_number") seasonNumber: Int,
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "pt-BR"
    ): TmdbSeasonDetailsDto
}
