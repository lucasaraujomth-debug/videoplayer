package com.example.mediahub.domain.repository

import com.example.mediahub.domain.model.StreamSource

interface StreamExtractor {
    val name: String
    suspend fun searchAndExtract(query: String, year: Int?): List<StreamSource>
}
