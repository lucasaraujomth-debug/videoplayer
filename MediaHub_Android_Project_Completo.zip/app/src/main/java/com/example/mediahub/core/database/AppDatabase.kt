package com.example.mediahub.core.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "continue_watching")
data class WatchProgressEntity(
    @PrimaryKey val tmdbId: Int,
    val mediaType: String,
    val title: String,
    val posterPath: String?,
    val seasonNumber: Int?,
    val episodeNumber: Int?,
    val lastStreamUrl: String,
    val refererHeader: String,
    val userAgentHeader: String,
    val originHeader: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAtEpochMs: Long
)

@Entity(tableName = "favorites")
data class FavoriteMediaEntity(
    @PrimaryKey val tmdbId: Int,
    val mediaType: String,
    val title: String,
    val posterPath: String?,
    val voteAverage: Double,
    val addedAtEpochMs: Long
)

@Dao
interface WatchHistoryDao {

    @Query("SELECT * FROM continue_watching ORDER BY updatedAtEpochMs DESC LIMIT 30")
    fun observeContinueWatching(): Flow<List<WatchProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWatchProgress(entity: WatchProgressEntity)

    @Query("DELETE FROM continue_watching WHERE tmdbId = :tmdbId")
    suspend fun removeWatchProgress(tmdbId: Int)

    @Query("SELECT * FROM favorites ORDER BY addedAtEpochMs DESC")
    fun observeFavorites(): Flow<List<FavoriteMediaEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE tmdbId = :tmdbId)")
    suspend fun isFavorite(tmdbId: Int): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(entity: FavoriteMediaEntity)

    @Query("DELETE FROM favorites WHERE tmdbId = :tmdbId")
    suspend fun removeFavorite(tmdbId: Int)
}

@Database(
    entities = [WatchProgressEntity::class, FavoriteMediaEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchHistoryDao(): WatchHistoryDao
}
