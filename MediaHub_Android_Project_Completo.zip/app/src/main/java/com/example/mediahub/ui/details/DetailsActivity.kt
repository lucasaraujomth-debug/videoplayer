package com.example.mediahub.ui.details

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.lifecycle.lifecycleScope
import com.example.mediahub.MediaHubApp
import com.example.mediahub.domain.model.MediaDetails
import com.example.mediahub.ui.player.PlayerActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailsActivity : AppCompatActivity() {

    private lateinit var contentLayout: LinearLayout
    private lateinit var episodesLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val tmdbId = intent.getIntExtra(EXTRA_TMDB_ID, 1001)
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE) ?: "movie"

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0E1015.toInt())
        }
        contentLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36)
        }
        scroll.addView(contentLayout)
        setContentView(scroll)

        loadDetails(mediaType, tmdbId)
    }

    private fun loadDetails(mediaType: String, tmdbId: Int) {
        val repo = MediaHubApp.instance.catalogRepository
        lifecycleScope.launch {
            val details = withContext(Dispatchers.IO) {
                repo.getMediaDetails(mediaType, tmdbId)
            }
            renderDetails(details)
        }
    }

    private fun renderDetails(details: MediaDetails) {
        contentLayout.removeAllViews()

        val titleView = TextView(this).apply {
            text = "${details.item.title} (${details.item.releaseYear ?: "N/A"})"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val metaView = TextView(this).apply {
            text = "Nota TMDB: ★ ${details.item.rating}  |  Gêneros: ${details.genres.joinToString(", ")}"
            textSize = 14f
            setTextColor(0xFF64B5F6.toInt())
            setPadding(0, 12, 0, 16)
        }
        val synopsisView = TextView(this).apply {
            text = details.item.overview
            textSize = 15f
            setTextColor(0xFFCFD8DC.toInt())
            setPadding(0, 0, 0, 20)
        }
        val castView = TextView(this).apply {
            val castText = details.cast.joinToString(", ") { "${it.name} (${it.character})" }
            text = "Elenco Principal: ${castText.ifBlank { "Não informado" }}"
            textSize = 13f
            setTextColor(0xFF90A4AE.toInt())
            setPadding(0, 0, 0, 24)
        }

        val favBtn = Button(this).apply {
            text = if (details.isFavorite) "★ Remover dos Favoritos" else "☆ Adicionar aos Favoritos"
            setOnClickListener {
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        MediaHubApp.instance.catalogRepository.toggleFavorite(details.item)
                    }
                    Toast.makeText(this@DetailsActivity, "Favoritos atualizado!", Toast.LENGTH_SHORT).show()
                    loadDetails(details.item.mediaType, details.item.tmdbId)
                }
            }
        }

        val playBtn = Button(this).apply {
            text = "▶ Reproduzir Stream HLS (Com Modo Dormir / OLED Blackout)"
            setOnClickListener {
                openPlayer(
                    title = details.item.title,
                    tmdbId = details.item.tmdbId,
                    mediaType = details.item.mediaType,
                    season = null,
                    episode = null
                )
            }
        }

        contentLayout.addView(titleView)
        contentLayout.addView(metaView)
        contentLayout.addView(synopsisView)
        contentLayout.addView(castView)
        contentLayout.addView(favBtn)
        contentLayout.addView(playBtn)

        if (details.seasons.isNotEmpty()) {
            val seasonTitle = TextView(this).apply {
                text = "Seletor de Temporadas"
                textSize = 18f
                setTextColor(0xFF64B5F6.toInt())
                setPadding(0, 32, 0, 12)
            }
            contentLayout.addView(seasonTitle)

            val seasonSelectorRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            details.seasons.forEach { season ->
                val sBtn = Button(this).apply {
                    text = season.name
                    setOnClickListener {
                        loadSeasonEpisodes(details.item.tmdbId, details.item.title, season.seasonNumber)
                    }
                }
                seasonSelectorRow.addView(sBtn)
            }
            contentLayout.addView(seasonSelectorRow)

            episodesLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 16, 0, 0)
            }
            contentLayout.addView(episodesLayout)

            loadSeasonEpisodes(details.item.tmdbId, details.item.title, details.seasons.first().seasonNumber)
        }
    }

    private fun loadSeasonEpisodes(seriesId: Int, seriesTitle: String, seasonNumber: Int) {
        val repo = MediaHubApp.instance.catalogRepository
        lifecycleScope.launch {
            val episodes = withContext(Dispatchers.IO) {
                repo.getSeasonEpisodes(seriesId, seasonNumber)
            }
            episodesLayout.removeAllViews()
            episodes.forEach { ep ->
                val epBtn = Button(this@DetailsActivity).apply {
                    text = "T${ep.seasonNumber}:E${ep.episodeNumber} - ${ep.title}"
                    setOnClickListener {
                        openPlayer(
                            title = "$seriesTitle - T${ep.seasonNumber}:E${ep.episodeNumber}",
                            tmdbId = seriesId,
                            mediaType = "tv",
                            season = ep.seasonNumber,
                            episode = ep.episodeNumber
                        )
                    }
                }
                episodesLayout.addView(epBtn)
            }
        }
    }

    private fun openPlayer(
        title: String,
        tmdbId: Int,
        mediaType: String,
        season: Int?,
        episode: Int?
    ) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_TITLE, title)
            putExtra(PlayerActivity.EXTRA_TMDB_ID, tmdbId)
            putExtra(PlayerActivity.EXTRA_MEDIA_TYPE, mediaType)
            putExtra(PlayerActivity.EXTRA_SEASON_NUMBER, season ?: -1)
            putExtra(PlayerActivity.EXTRA_EPISODE_NUMBER, episode ?: -1)
            putExtra(
                PlayerActivity.EXTRA_STREAM_URL,
                "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
            )
        }
        startActivity(intent)
    }

    companion object {
        const val EXTRA_TMDB_ID = "extra_tmdb_id"
        const val EXTRA_MEDIA_TYPE = "extra_media_type"
    }
}
