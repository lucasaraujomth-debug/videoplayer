package com.example.mediahub.core.power

import android.os.CountDownTimer
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView

class ScreenSleepManager(
    private val window: Window,
    private val playerView: PlayerView,
    private val blackOverlayView: View,
    private val onSleepTriggered: () -> Unit
) : Player.Listener {

    private var sleepTimer: CountDownTimer? = null
    var isOledBlackoutActive: Boolean = false
        private set

    init {
        keepScreenAwake(true)
    }

    fun startSleepTimer(durationMinutes: Int, onTickRemainingMinutes: (Long) -> Unit = {}) {
        cancelSleepTimer()
        val durationMs = durationMinutes * 60 * 1000L

        sleepTimer = object : CountDownTimer(durationMs, 60_000L) {
            override fun onTick(millisUntilFinished: Long) {
                val minutesLeft = (millisUntilFinished / 60_000L) + 1
                onTickRemainingMinutes(minutesLeft)
            }

            override fun onFinish() {
                disableOledBlackout()
                keepScreenAwake(false)
                onSleepTriggered()
            }
        }.start()
    }

    fun cancelSleepTimer() {
        sleepTimer?.cancel()
        sleepTimer = null
    }

    fun enableOledBlackout(player: Player?) {
        if (isOledBlackoutActive) return
        isOledBlackoutActive = true

        blackOverlayView.visibility = View.VISIBLE

        val params = window.attributes
        params.screenBrightness = 0.01f
        window.attributes = params

        player?.clearVideoSurface()
        playerView.useController = false
    }

    fun disableOledBlackout(player: Player? = null) {
        if (!isOledBlackoutActive) return
        isOledBlackoutActive = false

        blackOverlayView.visibility = View.GONE

        val params = window.attributes
        params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = params

        playerView.useController = true
        if (player != null) {
            playerView.player = null
            playerView.player = player
        }
    }

    fun toggleOledBlackout(player: Player?): Boolean {
        if (isOledBlackoutActive) {
            disableOledBlackout(player)
        } else {
            enableOledBlackout(player)
        }
        return isOledBlackoutActive
    }

    fun keepScreenAwake(awake: Boolean) {
        if (awake) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        keepScreenAwake(isPlaying)
    }

    override fun onPlaybackStateChanged(playbackState: Int) {
        if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) {
            keepScreenAwake(false)
            disableOledBlackout()
        }
    }

    fun release() {
        cancelSleepTimer()
        keepScreenAwake(false)
    }
}
