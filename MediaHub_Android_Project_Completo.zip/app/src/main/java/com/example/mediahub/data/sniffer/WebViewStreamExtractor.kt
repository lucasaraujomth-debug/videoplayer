package com.example.mediahub.data.sniffer

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import com.example.mediahub.domain.model.StreamSource
import com.example.mediahub.domain.repository.StreamExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.URLEncoder
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.coroutines.resume

class WebViewStreamExtractor(
    private val appContext: Context,
    override val name: String = "WebVideoSniffer",
    private val baseUrlTemplate: String = "https://exemplo-portal.com/search?q=%s"
) : StreamExtractor {

    @SuppressLint("SetJavaScriptEnabled")
    override suspend fun searchAndExtract(query: String, year: Int?): List<StreamSource> {
        val isDirectUrl = query.startsWith("http://", true) || query.startsWith("https://", true)
        val targetUrl = if (isDirectUrl) {
            query
        } else {
            val searchQuery = if (year != null) "$query $year" else query
            val encodedQuery = withContext(Dispatchers.IO) {
                URLEncoder.encode(searchQuery, "UTF-8")
            }
            String.format(baseUrlTemplate, encodedQuery)
        }

        val collectedSources = CopyOnWriteArrayList<StreamSource>()

        withTimeoutOrNull(12_000L) {
            suspendCancellableCoroutine { continuation ->
                val mainHandler = Handler(Looper.getMainLooper())

                mainHandler.post {
                    val webView = WebView(appContext)
                    val userAgent = webView.settings.userAgentString

                    webView.settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        blockNetworkImage = true
                        cacheMode = WebSettings.LOAD_NO_CACHE
                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    }

                    val snifferClient = SnifferWebViewClient(
                        defaultUserAgent = userAgent,
                        onStreamDetected = { streamSource ->
                            collectedSources.add(streamSource)
                            if (continuation.isActive) {
                                mainHandler.post {
                                    webView.stopLoading()
                                    webView.destroy()
                                }
                                continuation.resume(Unit)
                            }
                        }
                    )

                    webView.webViewClient = snifferClient
                    webView.loadUrl(targetUrl)

                    mainHandler.postDelayed({
                        if (continuation.isActive) {
                            webView.evaluateJavascript(
                                """
                                (function() {
                                    var videos = document.querySelectorAll('video');
                                    videos.forEach(function(v) { v.muted = true; v.play(); });
                                    var playButtons = document.querySelectorAll('.play, .vjs-big-play-button, .jw-icon-display');
                                    playButtons.forEach(function(b) { b.click(); });
                                })();
                                """.trimIndent(),
                                null
                            )
                        }
                    }, 3_500L)

                    continuation.invokeOnCancellation {
                        mainHandler.post {
                            webView.stopLoading()
                            webView.destroy()
                        }
                    }
                }
            }
        }

        return collectedSources.distinctBy { it.url }
    }
}
