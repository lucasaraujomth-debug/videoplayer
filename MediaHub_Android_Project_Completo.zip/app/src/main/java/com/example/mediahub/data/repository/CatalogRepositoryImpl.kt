package com.example.mediahub.data.repository

import com.example.mediahub.core.database.FavoriteMediaEntity
import com.example.mediahub.core.database.WatchHistoryDao
import com.example.mediahub.core.database.WatchProgressEntity
import com.example.mediahub.data.remote.TmdbApiService
import com.example.mediahub.data.remote.TmdbMediaSummaryDto
import com.example.mediahub.domain.model.CastMember
import com.example.mediahub.domain.model.CatalogItem
import com.example.mediahub.domain.model.EpisodeItem
import com.example.mediahub.domain.model.MediaDetails
import com.example.mediahub.domain.model.SeasonSummary
import com.example.mediahub.domain.repository.CatalogRepository
import kotlinx.coroutines.flow.Flow

class CatalogRepositoryImpl(
    private val tmdbApi: TmdbApiService,
    private val dao: WatchHistoryDao,
    private val apiKey: String
) : CatalogRepository {

    override suspend fun getTrendingCatalog(): List<CatalogItem> {
        if (apiKey.isBlank() || apiKey == "SUA_CHAVE_TMDB_AQUI") {
            return demoCatalogItems()
        }
        return try {
            tmdbApi.getTrending(apiKey = apiKey).results.map { it.toDomain() }
        } catch (e: Exception) {
            demoCatalogItems()
        }
    }

    override suspend fun getMoviesByGenre(genreId: Int): List<CatalogItem> {
        if (apiKey.isBlank() || apiKey == "SUA_CHAVE_TMDB_AQUI") {
            return demoCatalogItems().filter { it.mediaType == "movie" }
        }
        return try {
            tmdbApi.discoverByGenre("movie", genreId, apiKey).results.map { it.toDomain("movie") }
        } catch (e: Exception) {
            demoCatalogItems().filter { it.mediaType == "movie" }
        }
    }

    override suspend fun getSeriesByGenre(genreId: Int): List<CatalogItem> {
        if (apiKey.isBlank() || apiKey == "SUA_CHAVE_TMDB_AQUI") {
            return demoCatalogItems().filter { it.mediaType == "tv" }
        }
        return try {
            tmdbApi.discoverByGenre("tv", genreId, apiKey).results.map { it.toDomain("tv") }
        } catch (e: Exception) {
            demoCatalogItems().filter { it.mediaType == "tv" }
        }
    }

    override suspend fun getMediaDetails(mediaType: String, tmdbId: Int): MediaDetails {
        val isFav = dao.isFavorite(tmdbId)
        if (apiKey.isBlank() || apiKey == "SUA_CHAVE_TMDB_AQUI") {
            val item = demoCatalogItems().find { it.tmdbId == tmdbId } ?: demoCatalogItems().first()
            return MediaDetails(
                item = item,
                genres = listOf("Ficção Científica", "Ação", "Suspense"),
                cast = listOf(
                    CastMember(1, "Ator Principal", "Protagonista", null),
                    CastMember(2, "Atriz Co-Protagonista", "Especialista", null)
                ),
                seasons = if (mediaType == "tv") listOf(
                    SeasonSummary(1, "Temporada 1", 8),
                    SeasonSummary(2, "Temporada 2", 10)
                ) else emptyList(),
                isFavorite = isFav
            )
        }

        val dto = tmdbApi.getMediaDetails(mediaType, tmdbId, apiKey)
        val releaseDate = dto.releaseDate ?: dto.firstAirDate
        val year = releaseDate?.take(4)?.toIntOrNull()

        val item = CatalogItem(
            tmdbId = dto.id,
            title = dto.title ?: dto.name ?: "Sem Título",
            overview = dto.overview ?: "",
            posterUrl = dto.posterPath?.let { "$TMDB_IMAGE_BASE$it" },
            backdropUrl = dto.backdropPath?.let { "$TMDB_BACKDROP_BASE$it" },
            rating = dto.voteAverage ?: 0.0,
            mediaType = mediaType,
            releaseYear = year
        )

        return MediaDetails(
            item = item,
            genres = dto.genres?.map { it.name }.orEmpty(),
            cast = dto.credits?.cast?.take(15)?.map {
                CastMember(
                    id = it.id,
                    name = it.name,
                    character = it.character ?: "",
                    profileUrl = it.profilePath?.let { p -> "$TMDB_IMAGE_BASE$p" }
                )
            }.orEmpty(),
            seasons = dto.seasons?.filter { it.seasonNumber > 0 }?.map {
                SeasonSummary(it.seasonNumber, it.name, it.episodeCount)
            }.orEmpty(),
            isFavorite = isFav
        )
    }

    override suspend fun getSeasonEpisodes(seriesId: Int, seasonNumber: Int): List<EpisodeItem> {
        if (apiKey.isBlank() || apiKey == "SUA_CHAVE_TMDB_AQUI") {
            return (1..6).map { ep ->
                EpisodeItem(
                    id = seriesId * 100 + ep,
                    seasonNumber = seasonNumber,
                    episodeNumber = ep,
                    title = "Episódio $ep - Operação Noturna",
                    overview = "Episódio demonstrativo pronto para extração ou teste HLS.",
                    stillUrl = null
                )
            }
        }
        val dto = tmdbApi.getSeasonEpisodes(seriesId, seasonNumber, apiKey)
        return dto.episodes?.map {
            EpisodeItem(
                id = it.id,
                seasonNumber = seasonNumber,
                episodeNumber = it.episodeNumber,
                title = it.name,
                overview = it.overview ?: "",
                stillUrl = it.stillPath?.let { p -> "$TMDB_IMAGE_BASE$p" }
            )
        }.orEmpty()
    }

    override fun observeContinueWatching(): Flow<List<WatchProgressEntity>> =
        dao.observeContinueWatching()

    override fun observeFavorites(): Flow<List<FavoriteMediaEntity>> =
        dao.observeFavorites()

    override suspend fun saveWatchProgress(entity: WatchProgressEntity) {
        dao.upsertWatchProgress(entity)
    }

    override suspend fun toggleFavorite(item: CatalogItem) {
        if (dao.isFavorite(item.tmdbId)) {
            dao.removeFavorite(item.tmdbId)
        } else {
            dao.addFavorite(
                FavoriteMediaEntity(
                    tmdbId = item.tmdbId,
                    mediaType = item.mediaType,
                    title = item.title,
                    posterPath = item.posterUrl,
                    voteAverage = item.rating,
                    addedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
    }

    private fun TmdbMediaSummaryDto.toDomain(forcedType: String? = null): CatalogItem {
        val resolvedType = forcedType ?: mediaType ?: if (title != null) "movie" else "tv"
        val rawDate = releaseDate ?: firstAirDate
        return CatalogItem(
            tmdbId = id,
            title = title ?: name ?: "Sem Título",
            overview = overview ?: "",
            posterUrl = posterPath?.let { "$TMDB_IMAGE_BASE$it" },
            backdropUrl = backdropPath?.let { "$TMDB_BACKDROP_BASE$it" },
            rating = voteAverage ?: 0.0,
            mediaType = resolvedType,
            releaseYear = rawDate?.take(4)?.toIntOrNull()
        )
    }

    private fun demoCatalogItems(): List<CatalogItem> = listOf(
        CatalogItem(
            tmdbId = 1001,
            title = "Big Buck Bunny (Demo HLS 1080p)",
            overview = "Stream aberto oficial de referência para validar o Media3 ExoPlayer, OLED Blackout Mode e Sleep Timer.",
            posterUrl = null,
            backdropUrl = null,
            rating = 8.9,
            mediaType = "movie",
            releaseYear = 2024
        ),
        CatalogItem(
            tmdbId = 1002,
            title = "Sintel Open Movie (Série Demo)",
            overview = "Série demonstrativa com seletor de temporadas e episódios integrado ao Room Database.",
            posterUrl = null,
            backdropUrl = null,
            rating = 9.1,
            mediaType = "tv",
            releaseYear = 2025
        )
    )

    companion object {
        private const val TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/w500"
        private const val TMDB_BACKDROP_BASE = "https://image.tmdb.org/t/p/w1280"
    }
}
