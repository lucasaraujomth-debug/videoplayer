package com.example.mediahub.data.sniffer

import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.mediahub.domain.model.StreamSource
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap

class SnifferWebViewClient(
    private val defaultUserAgent: String,
    private val onStreamDetected: (StreamSource) -> Unit
) : WebViewClient() {

    private val detectedUrls = ConcurrentHashMap.newKeySet<String>()

    private val blockedAdHosts = setOf(
        "doubleclick.net",
        "googlesyndication.com",
        "adservice.google.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "exoclick.com",
        "juicyads.com",
        "bet365.com",
        "1xbet.com",
        "mc.yandex.ru"
    )

    private val mediaUrlRegex = Regex(
        pattern = """(?i)\.(m3u8|mp4|mpd|mkv)(\?.*|#.*|$)|/hls/|/manifest\.m3u8|mime=video""",
        option = RegexOption.IGNORE_CASE
    )

    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? {
        val req = request ?: return null
        val urlString = req.url?.toString() ?: return null
        val host = req.url?.host?.lowercase() ?: ""

        if (isAdDomain(host)) {
            return createEmptyResourceResponse()
        }

        if (isMediaStreamCandidate(urlString, req.requestHeaders["Accept"])) {
            if (detectedUrls.add(urlString)) {
                val rawHeaders = req.requestHeaders ?: emptyMap()
                val pageReferer = rawHeaders["Referer"]
                    ?: rawHeaders["referer"]
                    ?: extractOriginFromUrl(urlString)

                val userAgent = rawHeaders["User-Agent"]
                    ?: rawHeaders["user-agent"]
                    ?: defaultUserAgent

                val origin = rawHeaders["Origin"]
                    ?: rawHeaders["origin"]
                    ?: extractOriginFromUrl(pageReferer)

                val normalizedHeaders = mapOf(
                    "Referer" to pageReferer,
                    "User-Agent" to userAgent,
                    "Origin" to origin
                )

                val source = StreamSource(
                    url = urlString,
                    quality = inferQualityFromUrl(urlString),
                    headers = normalizedHeaders
                )

                onStreamDetected(source)
            }
        }

        return super.shouldInterceptRequest(view, request)
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val targetUri = request?.url ?: return false
        val host = targetUri.host?.lowercase() ?: ""
        return isAdDomain(host)
    }

    private fun isAdDomain(host: String): Boolean {
        return blockedAdHosts.any { adHost ->
            host == adHost || host.endsWith(".$adHost")
        }
    }

    private fun isMediaStreamCandidate(url: String, acceptHeader: String?): Boolean {
        if (url.contains(".ts", ignoreCase = true) || url.contains(".m4s", ignoreCase = true)) {
            return false
        }
        if (mediaUrlRegex.containsMatchIn(url)) {
            return true
        }
        val accept = acceptHeader?.lowercase() ?: ""
        return accept.contains("application/vnd.apple.mpegurl") ||
            accept.contains("application/x-mpegurl") ||
            accept.contains("video/mp4")
    }

    private fun inferQualityFromUrl(url: String): String {
        return when {
            url.contains("2160", ignoreCase = true) || url.contains("4k", ignoreCase = true) -> "4K"
            url.contains("1080", ignoreCase = true) -> "1080p"
            url.contains("720", ignoreCase = true) -> "720p"
            url.contains("480", ignoreCase = true) -> "480p"
            url.contains(".m3u8", ignoreCase = true) -> "HLS Adaptativo"
            else -> "HD"
        }
    }

    private fun extractOriginFromUrl(url: String): String {
        return try {
            val uri = Uri.parse(url)
            if (uri.scheme != null && uri.host != null) {
                "${uri.scheme}://${uri.host}"
            } else {
                url
            }
        } catch (e: Exception) {
            url
        }
    }

    private fun createEmptyResourceResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "UTF-8",
            204,
            "No Content",
            mapOf("Access-Control-Allow-Origin" to "*"),
            ByteArrayInputStream(ByteArray(0))
        )
    }
}
